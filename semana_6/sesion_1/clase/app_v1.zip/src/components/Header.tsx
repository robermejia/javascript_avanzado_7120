import { FC } from "react";

const Header : FC = () => {    
    return(<header className="container-fluid">
        Header
    </header>);
}

export default Header;