import { FC } from "react";

const Footer : FC = () => {    
    return(<footer className="container-fluid">
        Footer
    </footer>);
}

export default Footer;