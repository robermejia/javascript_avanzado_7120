var express = require('express');
var router = express.Router();
const CNX = require('../database/database')

/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

/* Operaciones CRUD */
//Listado
router.get('/pokemons', (req, res) => {
  const QUERY = 'SELECT * FROM pokemons';
  CNX.query(QUERY, (error, result) => {
    if (error) {
      return res.status(500).json({ error: error.message });
    }
    res.json(result);
  });
});

//Obtener por ID
router.get('/pokemons/:id', (req, res) => {
  const { id } = req.params;
  const QUERY = 'SELECT * FROM pokemons WHERE id = ?';
  CNX.query(QUERY, [id], (error, result) => {
    if (error) {
      return res.status(500).json({ error: error.message });
    }
    if (result.length === 0) {
      return res.status(404).json({ error: 'Pokemon no encontrado' });
    }
    res.json(result[0]);
  });
});

//Agregar
router.post('/pokemons', (req, res) => {
  const { nombre, tipo, habilidad, nivel, salud_maxima } = req.body;
  const QUERY = 'INSERT INTO pokemons(nombre, tipo, habilidad, nivel, salud_maxima) VALUES (?,?,?,?,?)';
  CNX.query(QUERY, [nombre, tipo, habilidad, nivel, salud_maxima], (error, result) => {
    if (error) {
      return res.status(500).json({ error: error.message });
    }
    res.json({message: 'Pokemon agregado'});
  });
});

//Actualizar
router.put('/pokemons/:id', (req, res) => {
  const { id } = req.params;
  const { nombre, tipo, habilidad, nivel, salud_maxima } = req.body;
  const QUERY = 'UPDATE pokemons SET nombre = ?, tipo = ?, habilidad = ?, nivel = ?, salud_maxima = ? WHERE id = ?';
  CNX.query(QUERY, [nombre, tipo, habilidad, nivel, salud_maxima, id], (error, result) => {
    if (error) {
      return res.status(500).json({ error: error.message });
    }
    res.json({message: 'Pokemon actualizado'});
  });
});

//Eliminar
router.delete('/pokemons/:id', (req, res) => {
  const { id } = req.params;
  const QUERY = 'DELETE FROM pokemons WHERE id = ?';
  CNX.query(QUERY, [id], (error, result) => {
    if (error) {
      return res.status(500).json({ error: error.message });
    }
    if (result.length === 0) {
      return res.status(404).json({ error: 'Pokemon no encontrado' });
    }
    res.json({message: 'Pokemon eliminado'});
  });
});

module.exports = router;
