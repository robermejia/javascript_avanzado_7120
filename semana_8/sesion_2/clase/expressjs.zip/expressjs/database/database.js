const MYSQL = require('mysql2');
const CNX = MYSQL.createConnection(
    {
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'pokemon',
        port: 3306
    }
);

CNX.connect(
    (error) =>{
        if(error){
            console.log(`Error: ${error.message}`);
            console.log(error.stack);
            return;            
        }
        console.log('Conexión establecida');
        
    }
);

module.exports = CNX;